// Enemies our player must avoid




var Enemy = function(x,y,sprite,movement) {
    // Variables applied to each of our instances go here,
    // we've provided one for you to get started

    // The image/sprite for our enemies, this uses
   
    this.x=x;
    this.y=y;
    this.sprite = 'images/enemy-bug.png';
    this.movement=movement;

};

// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
   this.x=this.x +(this.movement*dt);

    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
if (this.x>505)
    {

        this.x=-50;
this.movement=150+Math.floor(Math.random()*222);

}

// collision detected
if(Player.x<this.x+83 && 
    this.x<Player.x+83 &&
    Player.y<this.y+60 &&
    this.y<Player.y+60)
{

    Player.x=202;
    Player.y=405;
}

};

// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Now write your own player class

var player= function(x,y,sprite) {
    
    this.x=x;
    this.y=y;
    this.sprite = 'char-boy.png';
};


//This class requires an update(), render() and
// a handleInput() method.


Player.prototype.update=function(dt){

};

player.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);

};

var arrows;


Player.prototype.handleInput=function(arrows)
{
if(arrows==='left' && this.x >0){
this.x=this.x-102;
};
if(arrows==='right' && this.x <405){
this.x=this.x+102;
};
if(arrows==='up' && this.y >0){
this.y=this.y-83;
};

if(arrows==='down' && this.y <405){
this.y=this.y+83;

};

// Now instantiate your objects.
// Place all enemy objects in an array called allEnemies

var ene1= new Enemy(60,200);
var ene2= new Enemy(140,200);
var ene3= new Enemy(223,200);
var allEnemies=[ene1,ene2,ene3];


// Place the player object in a variable called player

var ply= new Player(202,405);


// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
Player.handleInput();

document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});
