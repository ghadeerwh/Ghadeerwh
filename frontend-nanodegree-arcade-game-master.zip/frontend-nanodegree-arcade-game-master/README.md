**About the project**


This project is useful in training on game programming foundations on the collision detection code as arcade game...


**What is the arcade Game?**
It is a classic game which based on collision detection code...


**Resources**
Udacity
Udemy


